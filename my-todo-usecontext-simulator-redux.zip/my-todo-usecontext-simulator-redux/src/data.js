export const initialData = {
  app: {},
  todo: {
    data: []
  },
  profile: {}
};
