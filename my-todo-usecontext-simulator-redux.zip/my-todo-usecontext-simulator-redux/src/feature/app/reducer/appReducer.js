//constants

//actions

const initialData = {
  app: {}
};

//reducers
const appReducer = (state = initialData, { type, payload }) => {
  switch (type) {
    default:
      return state;
  }
};

export default appReducer;
