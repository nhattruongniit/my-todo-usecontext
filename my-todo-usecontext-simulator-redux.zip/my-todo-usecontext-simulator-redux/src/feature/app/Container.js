import React from "react";

// components
import { Todo } from "../../feature";

export function App() {
  return (
    <div className="App">
        <h1>Build Todo Apps with React Hook and Context API</h1>
        <Todo />
    </div>
  );
}
